document.addEventListener("DOMContentLoaded", (e) => {
    let logo = document.querySelector("#logo");
    let id_input = document.querySelector("#id_input");
    let xx = document.querySelector("#xx");
    let idfal = document.querySelector("#idfal");
    let pw_input = document.querySelector("pw_input");
    let name_input = document.querySelector("name_input");
    let email_input = document.querySelector("email_input");

    id_input.addEventListener("submit", (e) => {
        if([\w]{4,20} == false){

        }
    })

    pw_input.addEventListener("submit", (e) => {

    })

    logo.addEventListener("click", (e) => {
        
    })

})